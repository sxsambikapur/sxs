document.addEventListener('DOMContentLoaded', () => {

    /* =========================================
       1. FACILITIES TOGGLE FUNCTION
       ========================================= */
    const toggleBtn = document.getElementById("toggleBtn");
    
    if (toggleBtn) {
        toggleBtn.addEventListener("click", function() {
            const wrapper = document.getElementById("expandSection");
            const btnText = document.getElementById("btnText");
            const arrowIcon = this.querySelector('.material-symbols-rounded');
            
            // Toggle the 'open' class on the wrapper
            wrapper.classList.toggle("open");
            
            // Update Text and Icon Rotation based on state
            if (wrapper.classList.contains("open")) {
                btnText.innerText = "Show Less";
                arrowIcon.style.transform = 'rotate(180deg)';
                arrowIcon.style.transition = 'transform 0.3s ease';
            } else {
                btnText.innerText = "View All Facilities";
                arrowIcon.style.transform = 'rotate(0deg)';
                
                // Optional: Smooth scroll back to top of grid when closing
                document.querySelector('.facilities-grid').scrollIntoView({ 
                    behavior: 'smooth', 
                    block: 'start' 
                });
            }
        });
    }

    /* =========================================
       2. STATS COUNTER ANIMATION
       ========================================= */
    const statsSection = document.getElementById('statsSection');

    if (statsSection) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                // If the stats section is visible in the viewport
                if (entry.isIntersecting) {
                    
                    const counters = entry.target.querySelectorAll('.stat-number');
                    
                    counters.forEach(counter => {
                        // Get the target number from data-target attribute
                        const target = +counter.getAttribute('data-target');
                        
                        let count = 0;
                        const duration = 2000; // Animation duration in ms
                        const frameRate = 16;  // Approx 60fps (1000ms / 60)
                        const totalFrames = duration / frameRate;
                        const increment = target / totalFrames; 
    
                        const updateCount = () => {
                            count += increment;
                            
                            if (count < target) {
                                // Round up to avoid decimals during counting
                                counter.childNodes[0].nodeValue = Math.ceil(count);
                                requestAnimationFrame(updateCount);
                            } else {
                                // Ensure it ends exactly on the target
                                counter.childNodes[0].nodeValue = target;
                            }
                        };
                        
                        updateCount();
                    });
    
                    // Stop observing once the animation has started so it doesn't restart
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.15 }); // Trigger when 15% of the section is visible
    
        observer.observe(statsSection);
    }

});
